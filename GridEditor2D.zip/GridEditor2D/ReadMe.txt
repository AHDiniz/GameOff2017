###############################################################################

GridEditor2D 2015 by BurnnerGames

Manual: Window->GridEditor2D->Manual
or the direct link
https://docs.google.com/document/d/1QwIoZ8N_BU9oJ1qCEJASHn203qJ6fcbKWEwLC53pAqc/edit

Contact: burnnergames@gmail.com
Twitter: https://tinyurl.com/l39zcon

Thanks for purchasing!





License for the sprites:


	Every Sprite in this package is licensed CC0 (see below).

			------------------------------

	License (Creative Commons Zero, CC0)
	http://creativecommons.org/publicdomain/zero/1.0/

	You may use these graphics in personal and commercial projects.
	Credit (Kenney or www.kenney.nl) would be nice but is not mandatory.

			------------------------------

	Donate:   http://donate.kenney.nl/
	Request:  http://request.kenney.nl/


###############################################################################